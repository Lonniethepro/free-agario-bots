<?php

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'FireGento_MageBot',
    __DIR__ . DIRECTORY_SEPARATOR . 'src'
);
